clc
I = imread('qq1.jpg');
imshow(I)
size(I)
Ig = rgb2gray(I);
imshow(Ig)